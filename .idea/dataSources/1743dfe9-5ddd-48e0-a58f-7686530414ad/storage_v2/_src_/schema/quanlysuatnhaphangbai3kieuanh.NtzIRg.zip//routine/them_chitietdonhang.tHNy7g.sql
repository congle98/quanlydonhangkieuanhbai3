create
    definer = root@localhost procedure them_chitietdonhang(IN ipdonhang_id int, IN ipvattu_id int, IN ipsoluongdat int)
begin
    insert into chitietdonhang(donhang_id, vattu_id, soluongdat) VALUES
    (ipdonhang_id,ipvattu_id,ipsoluongdat);
end;

