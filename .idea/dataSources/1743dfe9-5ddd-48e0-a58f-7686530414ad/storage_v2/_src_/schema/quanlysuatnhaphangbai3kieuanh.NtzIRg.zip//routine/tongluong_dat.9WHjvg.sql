create
    definer = root@localhost procedure tongluong_dat(IN madonhang varchar(50))
begin
    select sum(soluongdat)
    from dondathang join chitietdonhang c on dondathang.id = c.donhang_id
    where ma_donhang = madonhang
    group by donhang_id;
end;

