create definer = root@localhost view vw_ctpxuat_vt_px as
select `quanlysuatnhaphangbai3kieuanh`.`phieuxuat`.`ma_phieuxuat` AS `ma_phieuxuat`,
       `quanlysuatnhaphangbai3kieuanh`.`phieuxuat`.`tenkhachhang` AS `tenkhachhang`,
       `v`.`ma_vt`                                                AS `ma_vt`,
       `v`.`ten_vt`                                               AS `ten_vt`,
       `c`.`soluongxuat`                                          AS `soluongxuat`,
       `c`.`dongiaxuat`                                           AS `dongiaxuat`,
       (`c`.`soluongxuat` * `c`.`dongiaxuat`)                     AS `Thành tiền`
from ((`quanlysuatnhaphangbai3kieuanh`.`phieuxuat` join `quanlysuatnhaphangbai3kieuanh`.`chitietphieuxuat` `c` on ((`quanlysuatnhaphangbai3kieuanh`.`phieuxuat`.`id` = `c`.`phieuxuat_id`)))
         join `quanlysuatnhaphangbai3kieuanh`.`vattu` `v` on ((`v`.`id` = `c`.`vattu_id`)));

