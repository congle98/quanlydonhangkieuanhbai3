create
    definer = root@localhost procedure tongtienxuat_vattu(IN mavattu varchar(50))
begin
    select sum(soluong*giatien) from vattu join tonkho t on vattu.id = t.vattu_id
    where ma_vt = mavattu
    group by vattu_id;
end;

