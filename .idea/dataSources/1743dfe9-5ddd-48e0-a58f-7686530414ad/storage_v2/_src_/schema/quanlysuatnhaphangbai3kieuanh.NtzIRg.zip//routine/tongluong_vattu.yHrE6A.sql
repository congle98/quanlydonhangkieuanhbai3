create
    definer = root@localhost procedure tongluong_vattu(IN mavattu varchar(50))
begin
    select soluong from vattu join tonkho t on vattu.id = t.vattu_id
    where ma_vt = mavattu;
end;

