create definer = root@localhost view vw_ctpnhap_vt_pn_dh as
select `quanlysuatnhaphangbai3kieuanh`.`phieunhap`.`ma_phieunhap` AS `ma_phieunhap`,
       `quanlysuatnhaphangbai3kieuanh`.`phieunhap`.`ngaynhap`     AS `ngaynhap`,
       `d`.`ma_donhang`                                           AS `ma_donhang`,
       `n`.`ma_ncc`                                               AS `ma_ncc`,
       `v`.`ma_vt`                                                AS `ma_vt`,
       `v`.`ten_vt`                                               AS `ten_vt`,
       `c`.`soluongnhap`                                          AS `soluongnhap`,
       `c`.`dongianhap`                                           AS `dongianhap`,
       (`c`.`soluongnhap` * `c`.`dongianhap`)                     AS `Thành tiền`
from ((((`quanlysuatnhaphangbai3kieuanh`.`phieunhap` join `quanlysuatnhaphangbai3kieuanh`.`chitietphieunhap` `c` on ((`quanlysuatnhaphangbai3kieuanh`.`phieunhap`.`id` = `c`.`phieunhap_id`))) join `quanlysuatnhaphangbai3kieuanh`.`vattu` `v` on ((`c`.`vattu_id` = `v`.`id`))) join `quanlysuatnhaphangbai3kieuanh`.`dondathang` `d` on ((`d`.`id` = `quanlysuatnhaphangbai3kieuanh`.`phieunhap`.`donhang_id`)))
         join `quanlysuatnhaphangbai3kieuanh`.`nhacungcap` `n` on ((`n`.`id` = `d`.`ncc_id`)));

