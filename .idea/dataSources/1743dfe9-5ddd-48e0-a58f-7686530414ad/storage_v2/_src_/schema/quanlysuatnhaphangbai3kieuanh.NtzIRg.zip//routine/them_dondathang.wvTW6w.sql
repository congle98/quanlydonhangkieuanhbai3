create
    definer = root@localhost procedure them_dondathang(IN madonhang varchar(50), IN ngaydathang date, IN ncc_id int)
begin
    insert into dondathang (ma_donhang, ngaydathang, ncc_id)
    values (madonhang,ngaydathang,ncc_id);
end;

